@extends('admin.admin_master')

@section('admin')

@section('title')
Admin - Profile
@endsection


@endsection