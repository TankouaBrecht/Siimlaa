    <!-- Modal -->
    <div class="modal fade" id="exampleModalCenter2" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true" style="">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document" >
    <div class="modal-content" style="height:500px;" >
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalCenterTitle"><span id="pname"></span></h5>
        <button type="button" class="close" data-dismiss="modal" id="closeModel" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" >
      <iframe id="video" width="100%" height="100%"
            src="">
     </iframe>
      </div>

    </div>
  </div>
</div>