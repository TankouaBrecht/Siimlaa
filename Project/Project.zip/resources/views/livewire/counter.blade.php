<div>
    <div>compteur : {{$count}}</div>
    <button class="btn" wire:click="increment">increment</button>
</div>
