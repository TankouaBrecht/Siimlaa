

<?php $__env->startSection('content'); ?>

<?php $__env->startSection('title'); ?>
MarketPlace | 404
<?php $__env->stopSection(); ?>


<!--=====================================
Breadcrumb
======================================-->  

<div class="ps-breadcrumb">

    <div class="container">

        <ul class="breadcrumb">

            <li><a href="index.html">Home</a></li>

            <li>404 Page</li>

        </ul>

    </div>

</div>

<!--=====================================
404 Content
======================================-->
<div class="ps-page--404">
    <div class="container">
        <div class="ps-section__content"><img src="<?php echo e(asset('frontend/img/404.jpg')); ?>" alt="">
            <h3>ohh! page not found</h3>
            <p>It seems we can't find what you're looking for. Perhaps searching can help or go back to<a href="index.html"> Homepage</a></p>
            <form class="ps-form--widget-search" action="do_action" method="get">
                <input class="form-control" type="text" placeholder="Search...">
                <button><i class="icon-magnifier"></i></button>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.main_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJETS\Siimlaa\Project\resources\views/errors/404.blade.php ENDPATH**/ ?>