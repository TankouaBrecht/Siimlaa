<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('sliders', function (Blueprint $table) {
            $table->id();
            $table->string('slider_offer_title_fr')->nullable();
            $table->string('slider_main_title_fr');
            $table->string('slider_secondary_title_fr');
            $table->string('slider_slug_fr');
            $table->string('slider_desc_fr')->nullable();
            $table->string('slider_action_title_fr')->nullable();
            $table->string('discount_price')->nullable();
            $table->string('slider_image')->nullable();
            $table->integer('status')->default(1);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('sliders');
    }
};
